These graphs could not be replecated.
Also,
they are not complete,
with N-G and VR completely missing.
Also during these results, the Information Gain configuration did not optimize at all, skewing the results in the Calvo models, etc..
